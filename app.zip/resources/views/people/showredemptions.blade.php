@extends('layouts.pagelayout')
@section('content') <!-- START DATATABLE EXPORT -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title">{{$pagetitle}}</h3>
                                    <div class="btn-group pull-right">
                                        <button class="btn btn-danger dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i> Export Data</button>
                                        <ul class="dropdown-menu">
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'json',escape:'false'});"><img src='img/icons/json.png' width="24"/> JSON</a></li>
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'json',escape:'false',ignoreColumn:'[2,3]'});"><img src='img/icons/json.png' width="24"/> JSON (ignoreColumn)</a></li>
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'json',escape:'true'});"><img src='img/icons/json.png' width="24"/> JSON (with Escape)</a></li>
                                            <li class="divider"></li>
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'xml',escape:'false'});"><img src='img/icons/xml.png' width="24"/> XML</a></li>
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'sql'});"><img src='img/icons/sql.png' width="24"/> SQL</a></li>
                                            <li class="divider"></li>
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'csv',escape:'false'});"><img src='img/icons/csv.png' width="24"/> CSV</a></li>
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'txt',escape:'false'});"><img src='img/icons/txt.png' width="24"/> TXT</a></li>
                                            <li class="divider"></li>
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'excel',escape:'false'});"><img src='img/icons/xls.png' width="24"/> XLS</a></li>
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'doc',escape:'false'});"><img src='img/icons/word.png' width="24"/> Word</a></li>
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'powerpoint',escape:'false'});"><img src='img/icons/ppt.png' width="24"/> PowerPoint</a></li>
                                            <li class="divider"></li>
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'png',escape:'false'});"><img src='img/icons/png.png' width="24"/> PNG</a></li>
                                            <li><a href="#" onClick ="$('#customers2').tableExport({type:'pdf',escape:'false'});"><img src='img/icons/pdf.png' width="24"/> PDF</a></li>
                                        </ul>
                                    </div>                                    
                                    
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table id="customers2" class="table datatable">
                                            <thead>
                                                <tr>
                                                    <th>Voucher ID</th>
                                                    <th>Issuance Date</th>
                                                    <th> Issuar Phone</th>
                                                    <th>Redemption Date</th>
                                                    <th>Phone</th>
                                                    <th>Retailer</th>
                                                     <th>Size</th>
                                                    <th>Retailer Name</th>
                                                    <th>Shop Name</th>
                                                    <th>Region</th>
                                                    <th>District</th>
                                                   
                                                </tr>
                                            </thead>
                                            <tbody>
                                            	@foreach($redemptions as $retailer)
                                                <tr>
                                                    <td>{{$retailer->voucherid}}</td>
                                                    <td>{{$retailer->issuancedate}}</td>
                                                    <td>{{$retailer->issuerphone}}</td>
                                                    <td>{{$retailer->redemptiondate}}</td>
                                                    <td>{{$retailer->redeemerphone}}</td>
                                                    <td>{{$retailer->retailerid}}</td>
                                                    <td>{{$retailer->size}}</td>
                                                    <td>{{$retailer->retailername}}</td>
                                                    <td>{{$retailer->shopname}}</td>
                                                    <td>{{$retailer->region}}</td>
                                                    <td>{{$retailer->district}}</td>
                                                    
                                                </tr>
                                                @endforeach
                                              
                                            </tbody>
                                        </table>                                    
                                    </div>
                                </div>
                            </div>
                            <!-- END DATATABLE EXPORT -->  
                            @endsection